Specifications {#specification}
=============

This chapter contains the detailed specifications information:

* @subpage specification__boolean_operations "Boolean Operations"
* @subpage specification__brep_format "BRep Format"
* @subpage specification__pbr_math "PBR math (rasterization)"