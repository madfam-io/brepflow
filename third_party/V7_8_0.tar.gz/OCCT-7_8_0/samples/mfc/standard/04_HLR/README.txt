HLR sample demonstrates hidden line removal algorithm.
It supports exact and polygonal HLR algorithms.

To try HLR you need to follow some steps:
1) to import model, which will displayed in 3d view.
2) to choose "File->Process HLR" or press "HLR' button in the toolbar.
   Dialog with options of HLR will be opened.
3) to press "Get shapes" button of the HLR dialog to
   display results in the 2d view.
   Optionally, this dialog allow to view chosen shapes 
   in his own view. Here you can choose needed direction
   of view and press "Update 2d" button to update shapes HLR 2d view.
