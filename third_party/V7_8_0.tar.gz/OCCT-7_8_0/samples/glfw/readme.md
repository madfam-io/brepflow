GLFW: 3D Viewer (C++|GLFW) {#occt_samples_glfw}
==================

A sample demonstrating usage of OCCT 3D Viewer within a window created using GLFW.

Use CMake to build the sample.

Platforms: Windows, macOS, Linux

Required: glfw
