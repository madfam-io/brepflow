Qt: Import/Export (C++|Qt Widgets) {#samples_qt_iesample}
==========

OCCT includes several samples based on Qt application framework.
These samples are available on all supported desktop platforms.

This Import Export programming sample contains 3D Viewer and Import / Export functionality.
The sample could be found within OCCT repository in folder `/samples/qt/IESample/`.

@figure{samples_qt.png}
