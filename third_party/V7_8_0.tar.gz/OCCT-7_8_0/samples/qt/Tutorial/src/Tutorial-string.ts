<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="ru_RU">
<context>
    <name>QObject</name>
    <message>
        <source>TIT_SAMPLE</source>
        <translation>Tutorial</translation>
    </message>
	<message>
        <source>INF_MAKE_BOTTLE</source>
        <translation>Making bottle .........</translation>
    </message>
	<message>
        <source>TBR_MAKEBOT</source>
        <translation>MakeBottle</translation>
    </message>
	<message>
        <source>INF_DONE</source>
        <translation>Done</translation>
    </message>
	<message>
        <source>TIT_ABOUT</source>
        <translation>Tutorial</translation>
    </message>
    </context>
</TS>
