<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="ru_RU">
<context>
    <name>QObject</name>
	<message>
        <source>ICON_MAKE_BOTTLE</source>
        <translation>Bottle.png</translation>
    </message>
</context>
</TS>
