
# ToBoolean Node

**Category:** Data / Convert

Convert to boolean

## Parameters

This node has no parameters.

## Inputs


### data
- **Type:** Data
- **Required:** Yes



## Outputs


### boolean
- **Type:** boolean




