
# ToNumber Node

**Category:** Data / Convert

Convert to number

## Parameters

This node has no parameters.

## Inputs


### data
- **Type:** Data
- **Required:** Yes



## Outputs


### number
- **Type:** number



### isValid
- **Type:** boolean




