
# FromJSON Node

**Category:** Data / Convert

Parse JSON

## Parameters

This node has no parameters.

## Inputs


### json
- **Type:** string
- **Required:** Yes



## Outputs


### data
- **Type:** Data



### isValid
- **Type:** boolean




