
# ToJSON Node

**Category:** Data / Convert

Convert to JSON

## Parameters


### pretty
- **Type:** boolean
- **Default:** false





## Inputs


### data
- **Type:** Data
- **Required:** Yes



## Outputs


### json
- **Type:** string




