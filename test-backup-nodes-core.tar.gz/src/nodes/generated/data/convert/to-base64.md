
# ToBase64 Node

**Category:** Data / Convert

Encode to Base64

## Parameters

This node has no parameters.

## Inputs


### data
- **Type:** Data
- **Required:** Yes



## Outputs


### base64
- **Type:** string




