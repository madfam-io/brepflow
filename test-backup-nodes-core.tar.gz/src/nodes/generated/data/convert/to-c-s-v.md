
# ToCSV Node

**Category:** Data / Convert

Convert to CSV

## Parameters


### delimiter
- **Type:** string
- **Default:** ","





### headers
- **Type:** boolean
- **Default:** true





## Inputs


### data
- **Type:** Data[][]
- **Required:** Yes



## Outputs


### csv
- **Type:** string




