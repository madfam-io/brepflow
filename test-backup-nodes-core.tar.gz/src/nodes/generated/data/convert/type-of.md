
# TypeOf Node

**Category:** Data / Convert

Get data type

## Parameters

This node has no parameters.

## Inputs


### data
- **Type:** Data
- **Required:** Yes



## Outputs


### type
- **Type:** string




