
# FromBase64 Node

**Category:** Data / Convert

Decode from Base64

## Parameters

This node has no parameters.

## Inputs


### base64
- **Type:** string
- **Required:** Yes



## Outputs


### data
- **Type:** Data




