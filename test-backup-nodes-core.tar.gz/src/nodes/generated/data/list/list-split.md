
# ListSplit Node

**Category:** Data / List

Split list

## Parameters

This node has no parameters.

## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



### index
- **Type:** number
- **Required:** Yes



## Outputs


### before
- **Type:** Data[]



### after
- **Type:** Data[]




