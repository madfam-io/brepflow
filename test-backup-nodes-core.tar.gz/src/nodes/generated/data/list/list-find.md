
# ListFind Node

**Category:** Data / List

Find items matching condition

## Parameters

This node has no parameters.

## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



### pattern
- **Type:** Data
- **Required:** Yes



## Outputs


### items
- **Type:** Data[]



### indices
- **Type:** number[]




