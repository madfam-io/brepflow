
# ListShift Node

**Category:** Data / List

Shift list items

## Parameters


### wrap
- **Type:** boolean
- **Default:** true





## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



### offset
- **Type:** number
- **Required:** Yes



## Outputs


### shifted
- **Type:** Data[]




