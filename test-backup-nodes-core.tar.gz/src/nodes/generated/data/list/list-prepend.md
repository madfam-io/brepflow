
# ListPrepend Node

**Category:** Data / List

Prepend to list

## Parameters

This node has no parameters.

## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



### item
- **Type:** Data
- **Required:** Yes



## Outputs


### result
- **Type:** Data[]




