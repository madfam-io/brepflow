
# ListLength Node

**Category:** Data / List

Get list length

## Parameters

This node has no parameters.

## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



## Outputs


### length
- **Type:** number




