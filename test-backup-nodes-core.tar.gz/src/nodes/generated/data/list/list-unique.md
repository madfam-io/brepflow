
# ListUnique Node

**Category:** Data / List

Remove duplicates

## Parameters

This node has no parameters.

## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



## Outputs


### unique
- **Type:** Data[]




