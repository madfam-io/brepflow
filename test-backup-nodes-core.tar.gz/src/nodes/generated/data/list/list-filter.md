
# ListFilter Node

**Category:** Data / List

Filter list by condition

## Parameters

This node has no parameters.

## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



### mask
- **Type:** boolean[]
- **Required:** Yes



## Outputs


### filtered
- **Type:** Data[]




