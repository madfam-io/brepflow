
# ListFlatten Node

**Category:** Data / List

Flatten nested lists

## Parameters


### depth
- **Type:** number
- **Default:** 1
- **Min:** 1
- **Max:** 10



## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



## Outputs


### flattened
- **Type:** Data[]




