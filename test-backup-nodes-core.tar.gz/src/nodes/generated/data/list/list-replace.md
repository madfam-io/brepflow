
# ListReplace Node

**Category:** Data / List

Replace item in list

## Parameters

This node has no parameters.

## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



### item
- **Type:** Data
- **Required:** Yes



### index
- **Type:** number
- **Required:** Yes



## Outputs


### result
- **Type:** Data[]




