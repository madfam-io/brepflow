
# ListItem Node

**Category:** Data / List

Get item at index

## Parameters


### wrap
- **Type:** boolean
- **Default:** false





## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



### index
- **Type:** number
- **Required:** Yes



## Outputs


### item
- **Type:** Data




