
# ListContains Node

**Category:** Data / List

Check if list contains item

## Parameters

This node has no parameters.

## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



### item
- **Type:** Data
- **Required:** Yes



## Outputs


### contains
- **Type:** boolean



### index
- **Type:** number




