
# ListShuffle Node

**Category:** Data / List

Randomize list order

## Parameters


### seed
- **Type:** number
- **Default:** -1





## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



## Outputs


### shuffled
- **Type:** Data[]




