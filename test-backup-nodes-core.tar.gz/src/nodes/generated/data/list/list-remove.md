
# ListRemove Node

**Category:** Data / List

Remove item from list

## Parameters

This node has no parameters.

## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



### index
- **Type:** number
- **Required:** Yes



## Outputs


### result
- **Type:** Data[]



### removed
- **Type:** Data




