
# ListPartition Node

**Category:** Data / List

Partition list into chunks

## Parameters

This node has no parameters.

## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



### size
- **Type:** number
- **Required:** Yes



## Outputs


### partitions
- **Type:** Data[][]




