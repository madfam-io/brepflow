
# ListSlice Node

**Category:** Data / List

Extract sublist

## Parameters

This node has no parameters.

## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



### start
- **Type:** number
- **Required:** Yes



### end
- **Type:** number
- **Required:** No



## Outputs


### sublist
- **Type:** Data[]




