
# ListReverse Node

**Category:** Data / List

Reverse list order

## Parameters

This node has no parameters.

## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



## Outputs


### reversed
- **Type:** Data[]




