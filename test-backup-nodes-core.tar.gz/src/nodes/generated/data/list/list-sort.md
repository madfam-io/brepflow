
# ListSort Node

**Category:** Data / List

Sort list

## Parameters


### ascending
- **Type:** boolean
- **Default:** true





## Inputs


### list
- **Type:** Data[]
- **Required:** Yes



### keys
- **Type:** number[]
- **Required:** No



## Outputs


### sorted
- **Type:** Data[]



### indices
- **Type:** number[]




