
# ListJoin Node

**Category:** Data / List

Join multiple lists

## Parameters

This node has no parameters.

## Inputs


### lists
- **Type:** Data[][]
- **Required:** Yes



## Outputs


### joined
- **Type:** Data[]




