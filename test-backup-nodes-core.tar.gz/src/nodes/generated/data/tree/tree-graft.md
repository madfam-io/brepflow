
# TreeGraft Node

**Category:** Data / Tree

Graft tree

## Parameters

This node has no parameters.

## Inputs


### tree
- **Type:** DataTree
- **Required:** Yes



## Outputs


### grafted
- **Type:** DataTree




