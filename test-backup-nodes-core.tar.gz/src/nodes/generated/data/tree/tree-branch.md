
# TreeBranch Node

**Category:** Data / Tree

Get tree branch

## Parameters

This node has no parameters.

## Inputs


### tree
- **Type:** DataTree
- **Required:** Yes



### path
- **Type:** string
- **Required:** Yes



## Outputs


### branch
- **Type:** Data[]




