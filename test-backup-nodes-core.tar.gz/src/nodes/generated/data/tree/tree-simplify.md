
# TreeSimplify Node

**Category:** Data / Tree

Simplify tree paths

## Parameters

This node has no parameters.

## Inputs


### tree
- **Type:** DataTree
- **Required:** Yes



## Outputs


### simplified
- **Type:** DataTree




