
# TreeMerge Node

**Category:** Data / Tree

Merge trees

## Parameters

This node has no parameters.

## Inputs


### treeA
- **Type:** DataTree
- **Required:** Yes



### treeB
- **Type:** DataTree
- **Required:** Yes



## Outputs


### merged
- **Type:** DataTree




