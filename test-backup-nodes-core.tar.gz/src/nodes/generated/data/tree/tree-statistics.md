
# TreeStatistics Node

**Category:** Data / Tree

Tree statistics

## Parameters

This node has no parameters.

## Inputs


### tree
- **Type:** DataTree
- **Required:** Yes



## Outputs


### branchCount
- **Type:** number



### itemCount
- **Type:** number



### depth
- **Type:** number




