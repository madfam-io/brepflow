
# TreeShift Node

**Category:** Data / Tree

Shift tree paths

## Parameters

This node has no parameters.

## Inputs


### tree
- **Type:** DataTree
- **Required:** Yes



### offset
- **Type:** number
- **Required:** Yes



## Outputs


### shifted
- **Type:** DataTree




