
# TreePaths Node

**Category:** Data / Tree

Get all tree paths

## Parameters

This node has no parameters.

## Inputs


### tree
- **Type:** DataTree
- **Required:** Yes



## Outputs


### paths
- **Type:** string[]




