
# TreePrune Node

**Category:** Data / Tree

Remove empty branches

## Parameters

This node has no parameters.

## Inputs


### tree
- **Type:** DataTree
- **Required:** Yes



## Outputs


### pruned
- **Type:** DataTree




