
# TreeExplode Node

**Category:** Data / Tree

Explode tree to branches

## Parameters

This node has no parameters.

## Inputs


### tree
- **Type:** DataTree
- **Required:** Yes



## Outputs


### branches
- **Type:** Data[][]




