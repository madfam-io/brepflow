
# TreeFlatten Node

**Category:** Data / Tree

Flatten tree

## Parameters


### depth
- **Type:** number
- **Default:** 1
- **Min:** 0
- **Max:** 10



## Inputs


### tree
- **Type:** DataTree
- **Required:** Yes



## Outputs


### flattened
- **Type:** DataTree




