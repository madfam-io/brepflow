
# StringFormat Node

**Category:** Data / String

Format string

## Parameters

This node has no parameters.

## Inputs


### template
- **Type:** string
- **Required:** Yes



### values
- **Type:** Data[]
- **Required:** Yes



## Outputs


### formatted
- **Type:** string




