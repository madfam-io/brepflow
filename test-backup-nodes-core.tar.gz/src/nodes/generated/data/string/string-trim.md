
# StringTrim Node

**Category:** Data / String

Trim whitespace

## Parameters


### mode
- **Type:** enum
- **Default:** "both"





## Inputs


### string
- **Type:** string
- **Required:** Yes



## Outputs


### trimmed
- **Type:** string




