
# StringCase Node

**Category:** Data / String

Change string case

## Parameters


### case
- **Type:** enum
- **Default:** "lower"





## Inputs


### string
- **Type:** string
- **Required:** Yes



## Outputs


### result
- **Type:** string




