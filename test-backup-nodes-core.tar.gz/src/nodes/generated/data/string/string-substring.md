
# StringSubstring Node

**Category:** Data / String

Extract substring

## Parameters

This node has no parameters.

## Inputs


### string
- **Type:** string
- **Required:** Yes



### start
- **Type:** number
- **Required:** Yes



### length
- **Type:** number
- **Required:** No



## Outputs


### substring
- **Type:** string




