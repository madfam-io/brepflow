
# StringSplit Node

**Category:** Data / String

Split string

## Parameters


### delimiter
- **Type:** string
- **Default:** ","





## Inputs


### string
- **Type:** string
- **Required:** Yes



## Outputs


### parts
- **Type:** string[]




