
# StringConcat Node

**Category:** Data / String

Concatenate strings

## Parameters


### separator
- **Type:** string
- **Default:** ""





## Inputs


### strings
- **Type:** string[]
- **Required:** Yes



## Outputs


### result
- **Type:** string




