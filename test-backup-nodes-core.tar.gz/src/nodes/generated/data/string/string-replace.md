
# StringReplace Node

**Category:** Data / String

Replace in string

## Parameters


### global
- **Type:** boolean
- **Default:** true





## Inputs


### string
- **Type:** string
- **Required:** Yes



### search
- **Type:** string
- **Required:** Yes



### replace
- **Type:** string
- **Required:** Yes



## Outputs


### result
- **Type:** string




