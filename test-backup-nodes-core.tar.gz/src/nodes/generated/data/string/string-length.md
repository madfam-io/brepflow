
# StringLength Node

**Category:** Data / String

String length

## Parameters

This node has no parameters.

## Inputs


### string
- **Type:** string
- **Required:** Yes



## Outputs


### length
- **Type:** number




