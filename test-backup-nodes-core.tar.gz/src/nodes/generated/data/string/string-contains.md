
# StringContains Node

**Category:** Data / String

Check if contains

## Parameters


### caseSensitive
- **Type:** boolean
- **Default:** true





## Inputs


### string
- **Type:** string
- **Required:** Yes



### search
- **Type:** string
- **Required:** Yes



## Outputs


### contains
- **Type:** boolean



### index
- **Type:** number




