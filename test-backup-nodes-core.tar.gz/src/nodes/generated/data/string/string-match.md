
# StringMatch Node

**Category:** Data / String

Match with regex

## Parameters


### global
- **Type:** boolean
- **Default:** false





## Inputs


### string
- **Type:** string
- **Required:** Yes



### pattern
- **Type:** string
- **Required:** Yes



## Outputs


### matches
- **Type:** string[]




