
# SetPartitions Node

**Category:** Data / Set

Set partitions

## Parameters


### k
- **Type:** number
- **Default:** 2
- **Min:** 2
- **Max:** 10



## Inputs


### set
- **Type:** Data[]
- **Required:** Yes



## Outputs


### partitions
- **Type:** Data[][][]




