
# SetCombinations Node

**Category:** Data / Set

Combinations of set

## Parameters


### k
- **Type:** number
- **Default:** 2
- **Min:** 1
- **Max:** 10



## Inputs


### set
- **Type:** Data[]
- **Required:** Yes



## Outputs


### combinations
- **Type:** Data[][]




