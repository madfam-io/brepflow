
# SetCartesianProduct Node

**Category:** Data / Set

Cartesian product

## Parameters

This node has no parameters.

## Inputs


### setA
- **Type:** Data[]
- **Required:** Yes



### setB
- **Type:** Data[]
- **Required:** Yes



## Outputs


### product
- **Type:** Data[][]




