
# SetPermutations Node

**Category:** Data / Set

Permutations of set

## Parameters


### k
- **Type:** number
- **Default:** -1
- **Min:** -1
- **Max:** 10



## Inputs


### set
- **Type:** Data[]
- **Required:** Yes



## Outputs


### permutations
- **Type:** Data[][]




