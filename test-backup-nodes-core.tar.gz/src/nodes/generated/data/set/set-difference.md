
# SetDifference Node

**Category:** Data / Set

Difference of sets

## Parameters

This node has no parameters.

## Inputs


### setA
- **Type:** Data[]
- **Required:** Yes



### setB
- **Type:** Data[]
- **Required:** Yes



## Outputs


### difference
- **Type:** Data[]




