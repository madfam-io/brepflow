
# SetSubset Node

**Category:** Data / Set

Check if subset

## Parameters

This node has no parameters.

## Inputs


### setA
- **Type:** Data[]
- **Required:** Yes



### setB
- **Type:** Data[]
- **Required:** Yes



## Outputs


### isSubset
- **Type:** boolean




