
# SetPowerSet Node

**Category:** Data / Set

Power set

## Parameters

This node has no parameters.

## Inputs


### set
- **Type:** Data[]
- **Required:** Yes



## Outputs


### powerSet
- **Type:** Data[][]




