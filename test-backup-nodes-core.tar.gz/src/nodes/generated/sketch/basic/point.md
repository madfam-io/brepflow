
# Point Node

**Category:** Sketch / Basic

Create a point

## Parameters


### x
- **Type:** number
- **Default:** 0
- **Min:** -10000
- **Max:** 10000



### y
- **Type:** number
- **Default:** 0
- **Min:** -10000
- **Max:** 10000



### z
- **Type:** number
- **Default:** 0
- **Min:** -10000
- **Max:** 10000



## Inputs

This node has no inputs.

## Outputs


### point
- **Type:** Point
- **Description:** Point vertex



