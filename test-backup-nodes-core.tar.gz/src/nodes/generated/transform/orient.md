
# Orient Node

**Category:** Transform

Orient shape to match reference orientation

## Parameters

This node has no parameters.

## Inputs


### shape
- **Type:** Shape
- **Required:** Yes



### fromDirection
- **Type:** Vector
- **Required:** Yes



### toDirection
- **Type:** Vector
- **Required:** Yes



## Outputs


### oriented
- **Type:** Shape




