
# MatrixTransform Node

**Category:** Transform

Apply transformation matrix

## Parameters

This node has no parameters.

## Inputs


### shape
- **Type:** Shape
- **Required:** Yes



### matrix
- **Type:** Matrix4x4
- **Required:** Yes
- **Description:** 4x4 transformation matrix


## Outputs


### transformed
- **Type:** Shape




