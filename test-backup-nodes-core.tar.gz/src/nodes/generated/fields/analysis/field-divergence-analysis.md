
# FieldDivergenceAnalysis Node

**Category:** Fields / Analysis

Calculate divergence of vector field

## Parameters

This node has no parameters.

## Inputs


### vectorField
- **Type:** VectorField
- **Required:** No



## Outputs


### divergenceField
- **Type:** Field




