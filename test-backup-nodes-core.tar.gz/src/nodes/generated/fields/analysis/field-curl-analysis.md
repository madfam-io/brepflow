
# FieldCurlAnalysis Node

**Category:** Fields / Analysis

Calculate curl of vector field

## Parameters

This node has no parameters.

## Inputs


### vectorField
- **Type:** VectorField
- **Required:** No



## Outputs


### curlField
- **Type:** VectorField




