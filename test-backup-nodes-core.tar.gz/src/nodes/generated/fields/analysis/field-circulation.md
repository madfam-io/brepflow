
# FieldCirculation Node

**Category:** Fields / Analysis

Calculate circulation along curve

## Parameters

This node has no parameters.

## Inputs


### vectorField
- **Type:** VectorField
- **Required:** No



### curve
- **Type:** Curve
- **Required:** Yes



## Outputs


### circulation
- **Type:** Number




