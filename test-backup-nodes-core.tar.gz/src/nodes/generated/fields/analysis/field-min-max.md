
# FieldMinMax Node

**Category:** Fields / Analysis

Find minimum and maximum field values

## Parameters

This node has no parameters.

## Inputs


### field
- **Type:** Field
- **Required:** No



### domain
- **Type:** Geometry
- **Required:** No



## Outputs


### min
- **Type:** Number



### max
- **Type:** Number



### minPoint
- **Type:** Point



### maxPoint
- **Type:** Point




