
# FieldFlux Node

**Category:** Fields / Analysis

Calculate flux through surface

## Parameters

This node has no parameters.

## Inputs


### vectorField
- **Type:** VectorField
- **Required:** No



### surface
- **Type:** Surface
- **Required:** Yes



## Outputs


### flux
- **Type:** Number




